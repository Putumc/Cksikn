<?php

namespace AlvinMask\CustomSkin;

use pocketmin\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\entity\Skin;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerChangeSkinEvent;

use AlvinMask\CustomSkin\Form\SimpleForm;

class Main extends PluginBase implements Listener{

    public $skin = [];

    public function onEnable() : void{
     $this->getLogger()->info(base64_decode("UGx1Z2luIERpbm9VSSBEaWJ1YXQgT2xlaCBBbHZpbk1hc2s="));
     if(($this->getDescription()->getAuthors()[0] !== base64_decode("QWx2aW5NYXNr")) || ($this->getDescription()->getName() !== base64_decode("RGlub1VJ"))){
      $this->getLogger()->info(base64_decode("TWFhZiBBbmRhIFRlbGFoIE1lbmd1YmFoIFViYWggUGx1Z2luIERpbm9VSQ=="));
      $this->getServer()->shutdown();
     }
     $this->getServer()->getPluginManager()->registerEvents($this, $this);
     foreach(["komodo.txt", "quadruped.txt", "diplodocus.txt", "robosaurus.txt", "geometry.json", "captainamerica.png", "fantasma.png", "sonic.txt", "spongebob.txt", "tiger.txt", "turkey.txt", "yeti.txt", "deadpool.png", "gokugod.png", "king.png", "merlin.png", "mikunakano.png", "sirenhead.png", "pacman.png", "dewawingred.png", "enderdragonwings.png", "pixie-wings2.png", "chukyomix14.png", "chukyomix29.png"] as $file){
      $this->saveResource($file);
     }
    }

    public function onCommand(CommandSender $p, Command $commad, string $label, array $args):bool{
    	if($commad->getName("cskin")){
    		if($p instanceof Player){
    			$this->DinoUI($p);
    			return true;
    		} else {
    			$p->sendMessage("please use command in game");
    			return true;
    		}
    	}
    }
    public function DinoUI($p){
    	$form = new SimpleForm(function(Player $p, Int $data = null){
    		if($data === null){
    			return true;
    		}
    		$nll = null;
    		switch($data){
    			case 0:
    				$p->setSkin($this->skin[$p->getName()]);
          			$p->sendSkin();
          			$p->sendMessage("§eSuccesfully Reset Skin.");
    			break;
    			case 1:
    				if($p->hasPermission("komodo.dino")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."komodo.txt")), "", "geometry."."komodo", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."komodo".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 2:
    				if($p->hasPermission("quadruped.dino")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."quadruped.txt")), "", "geometry."."quadruped", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."quadruped".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 3:
    				if($p->hasPermission("diplodocus.dino")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."diplodocus.txt")), "", "geometry."."diplodocus", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."diplodocus".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 4:
    				if($p->hasPermission("robosaurus.dino")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."robosaurus.txt")), "", "geometry."."robosaurus", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."robosaurus".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
				case 5:
    				if($p->hasPermission("captainamerica.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."captainamerica.png"), "", "geometry."."captainamerica", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."captainamerica".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
				case 6:
    				if($p->hasPermission("fantasma.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."fantasma.png"), "", "geometry."."fantasma", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."fantasma".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 7:
    				if($p->hasPermission("sonic.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."sonic.txt")), "", "geometry."."sonic", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."sonic".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 8:
    				if($p->hasPermission("spongebob.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."spongebob.txt")), "", "geometry."."spongebob", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."spongebob".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 9:
    				if($p->hasPermission("tiger.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."tiger.txt")), "", "geometry."."tiger", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."tiger".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 10:
    				if($p->hasPermission("turkey.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."turkey.txt")), "", "geometry."."turkey", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."turkey".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 11:
    				if($p->hasPermission("yeti.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), base64_decode(file_get_contents($this->getDataFolder()."yeti.txt")), "", "geometry."."yeti", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."yeti".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			case 12:
    				if($p->hasPermission("deadpool.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."deadpool.png"), "", "geometry."."deadpool", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."deadpool".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    		  case 13:
      		if($p->hasPermission("king.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."king.png"), "", "geometry."."king", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."king".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    	 	case 14:
    				if($p->hasPermission("merlin.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."merlin.png"), "", "geometry."."merlin", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."merlin".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
  			case 15:
    				if($p->hasPermission("mikunakano.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."mikunakano.png"), "", "geometry."."mikunakano", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."mikunakano".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    		case 16:
    				if($p->hasPermission("sirenhead.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."sirenhead.png"), "", "geometry."."sirenhead", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."sirenhead".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    		 case 17:
    				if($p->hasPermission("pacman.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."pacman.png"), "", "geometry."."pacman", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."pacman".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    		 case 18:
    				if($p->hasPermission("dewawingred.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."dewawingred.png"), "", "geometry."."dewawingred", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."dewawingred".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    		case 19:
    				if($p->hasPermission("enderdragonwings.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."enderdragonwings.png"), "", "geometry."."enderdragonwings", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."enderdragonwings5".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    		case 20:
    				if($p->hasPermission("pixie-wings2.skin")){
    					$p->setSkin(new Skin($p->getSkin()->getSkinId(), $this->encodeSkin($this->getDataFolder()."pixie-wings2.png"), "", "geometry."."pixie-wings2", file_get_contents($this->getDataFolder()."geometry.json")));
          				$p->sendSkin();
          				$p->sendMessage("§aSuccesfully Changed a Skin §r§f"."pixie-wings2".".");
    				} else {
    					$p->sendMessage("§cYou Do not have permission");
    				}
    			break;
    			
    		}
    	});
    	$form->setTitle("§f§lCustomSkin");
    	$form->addButton("§l§cReset Skin\n§rtap to reset", 0, "textures/blocks/barrier");
    	if($p->hasPermission("komodo.dino")){
    		$form->addButton("§l§eKomodo\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eKomodo\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("quadruped.dino")){
    		$form->addButton("§l§eQuadruped\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eQuadruped\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("diplodocus.dino")){
    		$form->addButton("§l§eDiplodocus\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eDiplodocus\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("robosaurus.dino")){
    		$form->addButton("§l§eRobosaurus\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eRobosaurus\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
		if($p->hasPermission("captainamerica.skin")){
    		$form->addButton("§l§eCaptain America\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eCaptain America\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    if($p->hasPermission("fantasma.skin")){
      $form->addButton("§l§eFantasma\n§rtap to use", 0, "textures/ui/check");
    } else {
      $form->addButton("§l§eFantasma\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("sonic.skin")){
    		$form->addButton("§l§eSonic\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eSonic\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("spongebob.skin")){
    		$form->addButton("§l§eSpongebob\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eSpongebob\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("tiger.skin")){
    		$form->addButton("§l§eTiger\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eTiger\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("turkey.skin")){
    		$form->addButton("§l§eTurkey\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eTurkey\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("yeti.skin")){
    		$form->addButton("§l§eYeti\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eYeti\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("deadpool.skin")){
    		$form->addButton("§l§eDeadpool\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eDeadpool\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("king.skin")){
    		$form->addButton("§l§eKing\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eKing\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("merlin.skin")){
    		$form->addButton("§l§eMerlin\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eMerlin\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("mikunakano.skin")){
    		$form->addButton("§l§eMikunakano\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eMikunakano\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("sirenhead.skin")){
    		$form->addButton("§l§eSirenhead\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eSirenhead\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("pacman.skin")){
    		$form->addButton("§l§ePacman\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§ePacman\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("dewawingred.skin")){
    		$form->addButton("§l§eDewawingred\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eDewawingred\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("enderdragonwings.skin")){
    		$form->addButton("§l§eEnderdragonwings\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§eEnderdragonwings\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	if($p->hasPermission("pixie-wings2.skin")){
    		$form->addButton("§l§ePixiewings\n§rtap to use", 0, "textures/ui/check");
    	} else {
    		$form->addButton("§l§ePixiewings\n§rtap to use", 0, "textures/ui/icon_lock");
    	}
    	$form->sendToPlayer($p);
    	return $form;
    }
    
    public function encodeSkin($path){
        $size = getimagesize($path);
        $img = @imagecreatefrompng($path);
        $skinbytes = "";
        for ($y = 0; $y < $size[1]; $y++) {
            for ($x = 0; $x < $size[0]; $x++) {
                $colorat = @imagecolorat($img, $x, $y);
                $a = ((~((int)($colorat >> 24))) << 1) & 0xff;
                $r = ($colorat >> 16) & 0xff;
                $g = ($colorat >> 8) & 0xff;
                $b = $colorat & 0xff;
                $skinbytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
    }
        @imagedestroy($img);
    return $skinbytes;
    }

    public function onPlayerJoin(PlayerJoinEvent $e){
     $p = $e->getPlayer();
     $this->skin[$p->getName()] = $p->getSkin();
    }

    public function onPlayerQuit(PlayerQuitEvent $e){
     $p = $e->getPlayer();
     unset($this->skin[$p->getName()]);
    }

    public function onPlayerChangeSkin(PlayerChangeSkinEvent $e){
     $p = $e->getPlayer();
     $this->skin[$p->getName()] = $p->getSkin();
    }

}